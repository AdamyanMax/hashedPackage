This is a Django project hashed with cython,for testing purposes only.
In the 'util.hello_world' there is a hello world function.

from util.hello_world import hello_world
